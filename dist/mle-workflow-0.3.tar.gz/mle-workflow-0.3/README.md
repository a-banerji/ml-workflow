# ml-workflow

Install Dependencies: pip install requirements.txt

Start the script on terminal: python main.py

start the ui: mlflow ui
